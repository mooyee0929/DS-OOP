#include "lab1_Q1.h"
#include <iostream>
#include <string>
#include <cmath>

using namespace std;

void QUADRATIC::print()
{
	/*
	PRINT QUADRATIC FORMULA
	*/
}

void QUADRATIC::add(QUADRATIC q)
{
	/*
	ADD TWO QUADRATIC FORMULAS
	*/
}

void QUADRATIC::discriminant()
{
	/*
	FIND DISCRIMINANT OF QUADRATIC FORMULA AND ANWSERS
	*/
}
#include"LinkedList.h"

LinkedList::LinkedList()
{
	head = NULL;
}

LinkedList::~LinkedList()
{
	Clear();
}


void LinkedList::Push_back(int x)
{
	//TODO: add a new node to the back of the list with value x
}

void LinkedList::Push_front(int x)
{
	//TODO: add a new node to the front of the list with value x
}

void LinkedList::Insert(int index, int x)
{
	//TODO: add a new node at position "index" of the list with value x
}

void LinkedList::Delete(int index)
{
	//TODO: delete the node at position "index"
}

void LinkedList::Reverse()
{
	//TODO: reverse all elements in the list
}

void LinkedList::Print()
{
	//TODO: print out all elements in the list
}

void LinkedList::Clear() 
{
	//TODO: delete all elements in the list
}